just a few methods that are decent dsc.gg/kaido
